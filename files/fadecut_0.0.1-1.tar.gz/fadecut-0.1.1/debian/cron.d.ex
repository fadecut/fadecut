#
# Regular cron jobs for the fadecut package
#
0 4	* * *	root	[ -x /usr/bin/fadecut_maintenance ] && /usr/bin/fadecut_maintenance
