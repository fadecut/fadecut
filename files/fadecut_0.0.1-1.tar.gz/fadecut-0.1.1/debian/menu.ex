?package(fadecut):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="fadecut" command="/usr/bin/fadecut"
